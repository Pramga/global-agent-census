# Deployment and continuous-running service

## What this package provides

- Containerized web service with a read-only JSON API.
- Background ingestion starts at service boot and repeats every six hours by default.
- Persistent SQLite history on the configured disk.
- Public landing page, pricing page, privacy-notice draft, and early-access form.
- Waitlist submissions stored in SQLite, with an admin-token-protected export endpoint.
- Stripe Checkout subscription scaffold, webhook handling, one-time API-key issuance, paid API authentication, and monthly request quotas.
- Health endpoint and counts/records endpoints.
- One Gunicorn worker is intentional: the background scheduler is process-local and must not run twice.

## Deploy on Render

For the full go-live checklist and explicit blockers, see [`NEXT_STEPS_TO_GO_LIVE.md`](NEXT_STEPS_TO_GO_LIVE.md).

Render supports Dockerfile-based deployments and health checks. The included `render.yaml` configures a persistent disk, Docker runtime, and `/healthz` health check. The persistent disk requires a paid persistent service plan; review current provider pricing before deploying.

1. Put this project directory in a GitHub repository. Include `census.py`, `service.py`, `sources.json`, `requirements.txt`, `Dockerfile`, and `render.yaml`.
2. In Render, create a new Blueprint from that repository and review the service and disk settings before applying.
3. Wait for the service to build and start. First source sync happens in the background; allow time for it to finish.
4. Check `https://YOUR-SERVICE.onrender.com/healthz` for process liveness.
5. Check `https://YOUR-SERVICE.onrender.com/readyz` for a completed, recent successful ingestion; it should return HTTP 503 until the first successful sync.
6. Check `https://YOUR-SERVICE.onrender.com/api/counts` and `/api/sources`.
7. Check the landing page at `/`, pricing at `/pricing`, privacy draft at `/privacy`, and terms draft at `/terms`.
8. Query records at `/api/agents?limit=50&offset=0`, or search with `/api/agents?q=weather`.

The app does not require secrets for the configured public MCP Registry. The waitlist endpoint requires `WAITLIST_IP_SALT` to be configured to at least 32 characters; it deliberately fails closed when the salt is missing. The readiness endpoint reports source success/failure counts without exposing internal exception text. Add credentials only if a future source's official API requires them, using the host's secret environment-variable facility. Never commit tokens.

## Configure waitlist and paid subscriptions

The public site and lead form work without Stripe, but paid checkout intentionally returns a setup error until configured. In the hosting dashboard, set these environment variables using secrets from your own accounts:

- `APP_BASE_URL`: exact public HTTPS origin, e.g. `https://your-service.onrender.com`.
- `STRIPE_SECRET_KEY`: Stripe secret API key appropriate for this service; begin in test mode.
- `STRIPE_PRICE_DEVELOPER`: Stripe recurring monthly Price ID for the $29 Developer plan.
- `STRIPE_PRICE_BUSINESS`: Stripe recurring monthly Price ID for the $99 Business plan.
- `STRIPE_WEBHOOK_SECRET`: webhook signing secret for `POST /billing/webhook`.
- `WAITLIST_ADMIN_TOKEN`: long random secret to retrieve waitlist leads.
- `WAITLIST_IP_SALT`: a separate long random secret used to hash source IPs for abuse limiting.

An `.env.example` file documents variable names only. Do not put real credentials in it or commit a populated `.env` file.

Create the two recurring prices in Stripe and configure a webhook for `checkout.session.completed`, `customer.subscription.updated`, and `customer.subscription.deleted`. The success page issues a raw API key once after verifying the checkout session and active subscription; store it securely. Do not use live-mode keys until terms, support contact, refund/cancellation policy, pricing, backups, and a successful end-to-end test are complete. Test with Stripe test mode first. The current billing scaffold is not a substitute for a formal security review or accounting/tax setup.

The early-access form requires explicit consent. Leads can be retrieved by an authenticated `GET /api/waitlist` request with `Authorization: Bearer YOUR_WAITLIST_ADMIN_TOKEN`. Never publish this token or place it in client-side code. Delete leads on request and define a retention period before production launch. `/privacy` is a draft and must be updated with the actual operator contact and real practices before accepting customer data.

## API routes

- `GET /` — landing page and early-access form.
- `GET /pricing` — subscription plan page.
- `GET /privacy` — privacy-notice draft; update before launch.
- `GET /terms` — terms-of-service draft; complete and review before launch.
- `GET /healthz` — process liveness; source outages do not trigger host restarts.
- `GET /readyz` — readiness check that requires a recent successful ingestion.
- `GET /api/pricing` — plan metadata in JSON.
- `POST /api/waitlist` — submit an early-access request with explicit consent.
- `GET /api/waitlist` — admin-only waitlist export (Bearer token required).
- `GET /api/counts` — three distinct census counts and latest check information.
- `GET /api/sources` — configured source inventory, enablement, scope, and coverage limitations.
- `GET /api/agents?limit=50&offset=0&q=...` — paginated, read-only record list with source provenance.
- `POST /billing/checkout` — create a Stripe subscription checkout session.
- `POST /billing/webhook` — verify Stripe events and synchronize subscription state.
- `GET /billing/success?session_id=...` — one-time activation page.
- `GET /billing/activate?session_id=...` — validates completed checkout and issues an API key once.
- `GET /api/v1/agents`, `/api/v1/counts`, `/api/v1/usage` — authenticated paid API; use `Authorization: Bearer YOUR_API_KEY`.

## Continuous operation notes

- Default refresh is every six hours (`REFRESH_SECONDS=21600`); minimum accepted value is 900 seconds.
- Keep one application worker, or move scheduling into a separate singleton worker/cron job before increasing web workers.
- SQLite is appropriate for an initial single-instance census. For high availability, concurrent ingestion, or multi-replica service, migrate to PostgreSQL and use a separate scheduler/queue with a distributed lock.
- Provider uptime does not equal ingestion freshness. Monitor `last_run_finished_at`, failed source runs, and last-checked timestamps.

## Scope and honest coverage

No authoritative, exhaustive list of every public AI-agent directory exists. Directories cover different populations (A2A agents, MCP servers, hosted APIs, marketplace listings, code frameworks, enterprise catalogs). A responsible census must publish its source inventory and gaps, not promise universal coverage.

The default source configuration currently includes the MCP Registry adapter. Other public directories require their actual public API/feed, pagination semantics, terms, and tested schema before being counted as ingested. Add them one by one, with dedicated adapters for APIs that do not provide a simple JSON feed. The public A2A Registry documents a public search endpoint at `https://api.a2a-registry.org/public/agents`, but its API page does not specify exhaustive pagination; do not represent a single search response as a complete dump. Source: https://www.a2a-registry.org/api-docs.

## Production blockers before claiming comprehensive coverage

- Build and maintain a reviewed inventory of public directories and API endpoints; current enabled sources are broader but still not comprehensive.
- Confirm each source's legal terms, robots/crawl policy, rate limits, pagination, and data license.
- Add pagination-aware source adapters and automated schema-contract tests.
- Add SSRF safeguards for endpoint validation (DNS/IP range checks at connect time, redirects revalidated, block private/loopback/link-local ranges), response limits, backoff, and rate limits before broad public crawling.
- Add operator verification evidence review and merge/split workflows.
- Add alerts, backups, restore tests, structured metrics, and a public source coverage page.
