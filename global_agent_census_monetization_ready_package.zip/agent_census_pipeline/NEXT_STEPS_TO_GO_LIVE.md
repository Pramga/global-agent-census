# Exact remaining steps to go live safely

This package has been tested locally, but is not deployed. The operator must connect their own accounts and set production secrets. Do not send credentials in chat or commit them to Git.

## 1. Create a private GitHub repository

1. Create a repository named `global-agent-census` under an account you control.
2. Upload the contents of this package's `agent_census_pipeline/` folder to the repository root (including `render.yaml`, `Dockerfile`, `census.py`, `service.py`, `sources.json`, `requirements.txt`, and `site/`).
3. Do not upload `.env`, databases, API keys, customer leads, or payment secrets.
4. Review the repository contents before connecting it to hosting.

## 2. Create the hosting service

1. In Render, choose **New → Blueprint** and connect the repository.
2. Review the generated service and persistent disk before confirming. The included configuration uses a paid Starter service and a 10 GB persistent disk; verify current pricing and change disk size if appropriate before approving charges.
3. Set the required secret environment values in Render. Generate two different random secrets of at least 32 characters for `WAITLIST_ADMIN_TOKEN` and `WAITLIST_IP_SALT`.
4. Leave all Stripe values unset until the public beta and legal pages are reviewed. Stripe checkout should remain disabled.
5. Deploy, then check `/healthz`, `/readyz`, `/api/counts`, `/api/sources`, `/`, `/pricing`, `/privacy`, and `/terms`. `/readyz` should only return HTTP 200 after a successful recent ingestion.

## 3. Validate data before public promotion

1. Review `/api/sources` and each source's coverage note.
2. Check that the first ingestion succeeded and records include source provenance.
3. Manually inspect a sample from each enabled source, including duplicates, records without endpoints, and unreachable endpoints.
4. Confirm that directory entries, endpoint reachability, and independent operator verification are reported as distinct states.
5. Do not claim exhaustive global coverage; no authoritative complete list of all public AI-agent directories is known.

## 4. Run billing in test mode only

Before enabling subscriptions, fill in the actual operator/contact details in `/privacy` and `/terms`, and publish a clear cancellation/refund policy. Review data-source licenses, acceptable-use terms, customer support process, retention, backups, and applicable tax/business obligations.

1. Create recurring Stripe test prices: Developer at $29/month and Business at $99/month, or update prices to what customer research supports.
2. Configure test-mode `STRIPE_SECRET_KEY`, the two `STRIPE_PRICE_*` values, `STRIPE_WEBHOOK_SECRET`, and `APP_BASE_URL` in the hosting secret manager.
3. Configure webhook events `checkout.session.completed`, `customer.subscription.updated`, and `customer.subscription.deleted` for `/billing/webhook`.
4. Test checkout, successful activation, failed/expired subscription, cancellation, duplicate webhooks, monthly quota enforcement, API key storage, and the one-time API key display.
5. Only move to live Stripe keys after the end-to-end test and independent security review succeed.

## 5. Security and reliability gate

- Perform a dependency vulnerability scan and production security review.
- Verify backups and complete a restore test.
- Set uptime and ingestion-failure alerts.
- Test lead export with the correct admin token and confirm unauthenticated requests fail.
- Define data retention and a process for correction/removal requests.
- Keep only one web worker until ingestion scheduling is moved to a separate singleton worker or distributed scheduler.

## What is not done

No repository, hosting account, Stripe account, or custom domain is connected by this package. No live deployment, live ingestion, live payment, legal review, or paying-customer validation has been completed. A successful local test suite is not a production security certification.
