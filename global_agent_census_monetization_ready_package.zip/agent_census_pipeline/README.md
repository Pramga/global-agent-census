# Global AI Agent Census pipeline

Version 0.2.0 — runnable ingestion foundation

## What this implements

1. **Ingest**: official MCP Registry pagination plus configurable public JSON feeds.
2. **Deduplicate**: stable canonical identity first, normalized endpoint second, metadata URL third; source records remain linked to the surviving entity.
3. **Validate**: conservative public HTTP checks and A2A Agent Card field checks. It does not invoke tasks/tools or prove that an agent behaves correctly.
4. **Track**: SQLite first/last-seen timestamps, last-check time, snapshots, metadata-change events, source-run history, and validation events.
5. **Count separately**:
   - `listed_unique_records`: all deduplicated entities seen in enabled sources.
   - `validated_reachable_records`: metadata validation passed and endpoint was reachable on last check.
   - `independently_verified_operators`: distinct operator identities with the explicit `independently_verified` status and recorded evidence. The pipeline deliberately does not grant this status automatically.

## Important scope note

There is no authoritative global inventory of every AI agent. Public directories have different scopes: an MCP server, A2A agent, SDK, framework, and marketplace listing are not interchangeable. Keep frameworks and SDKs in a separate catalog rather than counting them as deployed agents. Publish a source-by-source coverage statement with every count.

## Requirements

- Python 3.11+
- Install `requirements.txt` for the web service (Gunicorn and Stripe SDK). The core ingestion pipeline uses the standard library.
- Outbound HTTPS access from the machine running ingestion

## Run once

```bash
python census.py --config sources.json --db census.sqlite3 --out public
```

Recheck every known record immediately:

```bash
python census.py --config sources.json --db census.sqlite3 --out public --force-check
```

Read current counts without re-ingesting:

```bash
python census.py --db census.sqlite3 --counts-only
```

Outputs:
- `public/agents.json`
- `public/agents.csv`
- `public/counts.json`
- `public/run_report.json`
- `census.sqlite3` (history and provenance)

## Add a public source

Use the `json_feed` adapter when a directory publishes a public JSON array or object containing an array. Configure `items_key` and `field_map` in `sources.json`. Example:

```json
{
  "name": "Public A2A directory",
  "adapter": "json_feed",
  "url": "https://directory.example/agents.json",
  "items_key": "agents",
  "kind": "agent",
  "protocol": "A2A",
  "enabled": true,
  "field_map": {
    "source_record_id": "id",
    "name": "name",
    "description": "description",
    "primary_endpoint": "endpoint",
    "metadata_url": "agent_card_url",
    "canonical_identity": "publisher.id"
  }
}
```

Do not enable a source until you have checked its real endpoint, schema, pagination, license/terms, robots policy, and rate limits. For directories with a bespoke API, implement a dedicated adapter rather than scraping a UI page.

## Deduplication behavior and review

Identity key order:
1. source-published canonical identity / namespace,
2. normalized endpoint,
3. normalized metadata URL,
4. source-specific record key.

Records from each source are preserved in `source_records`. If two unrelated agents share an endpoint, or a publisher changes its namespace, automated matching can still make mistakes. Review merges and splits before public release. A production deployment should add an explicit `entity_aliases`/merge-review table and never destructively discard source records.

## Validation semantics

- A2A records: attempts to fetch an explicitly declared metadata URL, then `/.well-known/agent-card.json`; checks for a name, interface/endpoint, and a skills array.
- MCP records: a basic HTTP reachability check on a declared URL, if present. This is **not** an MCP handshake and does not establish that the server is functioning correctly.
- Generic records: basic HTTP reachability only.
- No agent task execution, MCP tool call, JSON-RPC invocation, credential handling, or authenticated probing is performed.
- An HTTP response does not mean the service is safe, trustworthy, or capable.
- Use a controlled egress environment and consider SSRF protections before running on shared infrastructure. The starter script is intended for a trusted operator-run batch job, not an exposed public API.

## Operator verification

The pipeline defaults to `unverified` or `source_claim`. It does not infer real-world ownership from DNS names, directory inclusion, a live endpoint, or a self-reported profile. An operator should only be marked `independently_verified` after recording evidence such as a completed domain-control challenge, verified publisher namespace, cryptographic signature verified against a trusted key, or documented human review. Add an auditable review workflow before manually changing the status.

## Scheduling

Use cron, systemd timer, GitHub Actions, or a managed scheduler. A simple daily cron entry (adjust paths):

```cron
15 3 * * * cd /opt/agent-census && /usr/bin/python3 census.py --config sources.json --db census.sqlite3 --out public >> census.log 2>&1
```

Do not publish a "live" or "real-time" label unless a run timestamp and health signal are exposed. Include source freshness, failures, and scope limitations in the public dashboard.

## Known gaps before production

- Only the official MCP Registry adapter is implemented out of the box. Other directories require their actual public API/feed URL and schema; the JSON adapter is configurable but not a universal scraper.
- No deployment host, scheduler, public database, dashboard, or alerting is provisioned by this package.
- The MCP Registry API response shape can evolve; monitor failed runs and pin/test the API contract.
- DNS rebinding/private-network SSRF safeguards, robots/terms enforcement, exponential backoff, concurrency limits, schema-version fixtures, signed-card verification, manual operator-review UI, and merge/split review are recommended before broad production deployment.


## Continuously running web service

See `DEPLOYMENT.md` for the Docker/Render deployment, background refresh worker, health endpoint, and read-only JSON API. The app is designed for a single worker and persistent disk. It is not deployed until connected to a hosting account and repository.


## Expanded source coverage (still incomplete)

Enabled adapters: official MCP Registry (cursor pagination), public A2A Registry (bounded search sample; not exhaustive), and the Awesome MCP Servers Markdown project directory (project links, not live agents). A Glama connector-directory adapter is available but disabled until `GLAMA_API_KEY` is configured. Glama's API data license requires visible credit and a direct link to each Glama listing wherever mirrored data is displayed. Inspect `/api/sources` for source scopes and coverage status. No universal exhaustive directory of public agents exists; never label the census complete.


## Early monetization scaffold

The package now includes a landing page (`/`), proposed pricing page (`/pricing`), draft privacy notice (`/privacy`), early-access intake (`POST /api/waitlist`), and Stripe subscription/API-key scaffolding. See `DEPLOYMENT.md` for environment variables and test-mode setup. Prices are hypotheses, not validated market prices. Paid business features such as watchlists and automated change alerts are roadmap items, not included capabilities yet. The privacy page requires operator contact details and legal review before production use.

Business launch assets are in `business/`: a 90-day execution plan, prospect interview script, and validation trackers.


## Going live safely

Follow [`NEXT_STEPS_TO_GO_LIVE.md`](NEXT_STEPS_TO_GO_LIVE.md) for the account setup, deployment, validation, and billing gates that remain before public launch.
