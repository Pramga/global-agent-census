# Global AI Agent Census — 90-Day Business Launch Plan

## Business objective

Validate a real paid problem, launch a credible public registry, and earn the first recurring subscription revenue without exceeding a $25–$100/month initial operating budget.

## Positioning

**Independent AI-agent discovery and intelligence:** source-attributed public records, clear freshness/validation labels, change history, and a structured API. Do not claim universal coverage, safety, capability, or independent verification unless evidence supports it.

## Initial customer hypotheses

1. AI software developers who need structured agent discovery data.
2. AI consultancies/agencies that evaluate tools for client work.
3. Product/research teams monitoring changes across the agent ecosystem.
4. Enterprise technology teams that need recurring reports and higher API quotas.

## Pricing hypotheses to test

- Free: public search, basic metadata, source links, and counts.
- Developer: $29/month; proposed 10,000 API requests/month.
- Business: $99/month; proposed 100,000 API requests/month and business-oriented reporting as those features become available.
- Enterprise: from $499/month only after validating the scope of support, quotas, and data feed requirements.

Do not describe roadmap features as available. Prices should be changed based on paid pilot feedback, cost-to-serve, and usage data.

## Days 1–14: customer discovery

- Build a list of 20 qualified prospects; prioritize people who already build or evaluate AI agents.
- Complete 10 discovery conversations.
- Ask about their current workflow, frequency of the problem, consequences, workarounds, and budget authority.
- Show sample data and ask the prospect to rank the three most valuable outcomes.
- Ask for a paid pilot, not only verbal enthusiasm.
- Gate: at least three serious pilot prospects or revise the segment/problem before spending more.

## Days 15–30: credible public beta

- Deploy the app only after reviewing hosting cost and secret settings.
- Test source ingestion, health endpoint, freshness indicators, deduplication, backup and restore.
- Publish source inventory, source scope, last-check times, and definitions for listed/reachable/verified counts.
- Update privacy notice with the actual operator contact, retention policy, and processors.
- Test waitlist submission and deletion process.
- Gate: stable daily operation and no misleading completeness or verification claims.

## Days 31–60: paid API pilot

- Configure Stripe in test mode first; create monthly prices and signed webhooks.
- Test checkout, webhook retries, cancellation, API-key issuance exactly once, revoked/inactive subscriptions, quota enforcement, and monthly usage reset.
- Run API integration tests and security review before live payments.
- Onboard 3 pilot customers; personally review their usage and issues weekly.
- Gate: at least one successful paid pilot and evidence that customers use the data repeatedly.

## Days 61–90: retention and repeatable sales

- Add only the highest-demand business features (likely watchlists/change alerts or better exports) after validation.
- Review paid conversion, churn, API usage, data freshness, failed source runs, support time, and gross margin weekly.
- Publish API docs and sample requests.
- Establish a support contact, cancellation instructions, refund policy, and a documented correction/removal workflow.
- Gate: 3–10 paying customers, repeat usage, known direct costs, and a clear reason customers renew.

## Weekly dashboard

- Prospects contacted; discovery calls completed; paid pilots offered; paid pilots closed.
- Waitlist sign-ups and source channel.
- Active paying customers; MRR; cancellations; net revenue after direct costs.
- API calls by plan; quota errors; repeat weekly users.
- Source success rate; last successful refresh; share of records checked recently; false merges reported.
- Customer-reported value and support hours per customer.

## Guardrails

- Do not purchase expensive infrastructure before customer validation.
- Do not claim “all public directories” or “all AI agents.” State exact source scope and known gaps.
- Do not call a record “verified” solely because it is listed or responds to HTTP.
- Respect source licenses, attribution, rate limits, and access policies.
- Never commit API keys, Stripe secrets, or admin tokens to source control.
- Keep a clear route for correction/removal requests and delete waitlist records on valid requests.
