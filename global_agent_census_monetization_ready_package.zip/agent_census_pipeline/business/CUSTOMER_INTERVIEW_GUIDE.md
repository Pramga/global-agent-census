# Customer Discovery Interview Guide

## Goal

Find out whether a specific customer has a recurring, costly problem that the Global AI Agent Census can solve. Do not lead with a sales pitch; listen first.

## 20-minute interview outline

### 1. Context (3 minutes)
- What is your role, and how do you currently discover or evaluate AI agents?
- How often do you do that work?
- Which protocols or ecosystems matter to you (for example, MCP, A2A, hosted APIs, or internal catalogs)?

### 2. Current workflow (6 minutes)
- Walk me through the last time you needed to find or compare agents.
- Which directories, repositories, docs, or spreadsheets did you use?
- What information was hardest to find or trust?
- How do you detect that a listing has changed or become unavailable?
- What happens when this data is wrong or stale?
- How much time does this take in a typical week or month?

### 3. Buying signal (5 minutes)
- Do you already pay for any data, monitoring, or developer APIs that solve a related problem?
- Who would approve a purchase like this?
- What would need to be true for this to be worth $29/month? What about $99/month?
- Which is more valuable: search/API access, history, alerts, exports, or team reports?
- Is there a current project where you could use a small pilot now?

### 4. Prototype reaction (3 minutes)
Show a small set of source-attributed records and explain the differences between listed, reachable, and independently verified. Ask:
- What would you use first?
- What is missing for your workflow?
- What would stop you from trusting or paying for this?

### 5. Close (3 minutes)
- Would you be willing to try a paid pilot if the one most important requirement is met?
- What price and scope would be reasonable for that pilot?
- May I follow up with a demo or proposal?

## Avoid

- “Would you use this?” without asking about past behavior.
- Treating compliments, waitlist sign-ups, or survey interest as proof of willingness to pay.
- Suggesting a feature before understanding the existing workflow.
- Promising comprehensive coverage or independent verification before it exists.

## Qualification score (0–2 each)

1. Problem occurs at least monthly.
2. Current workaround costs time or money.
3. Person has budget authority or access to buyer.
4. Need is urgent within 90 days.
5. Prospect agrees to a concrete next step or paid pilot.

A score of 7+ is a strong follow-up candidate; 4–6 needs more discovery; 0–3 is lower priority.
