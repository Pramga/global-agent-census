# Business launch assets

- `90_DAY_PLAN.md`: execution roadmap and launch gates.
- `CUSTOMER_INTERVIEW_GUIDE.md`: questions and qualification rubric for validating willingness to pay.
- `PROSPECT_TRACKER.csv`: starter prospect tracker with 20 blank rows.
- `LAUNCH_CHECKLIST.csv`: implementation and operational launch checklist.
- `Global_Agent_Census_Launch_Workbook.xlsx`: editable prospect tracker, interview notes, pricing/revenue model, launch checklist, and weekly metrics sheets.

These are planning tools, not evidence of customer demand or revenue. Update the assumptions with actual customer feedback and provider pricing.
