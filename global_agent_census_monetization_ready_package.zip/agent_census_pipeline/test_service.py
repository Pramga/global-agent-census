"""Small WSGI smoke tests; importing service must not launch an ingestion worker in tests."""
import hashlib
import io
import json
import os
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

_DB = tempfile.mktemp(prefix="gac-test-", suffix=".sqlite3")
os.environ["DATABASE_PATH"] = _DB
os.environ["WAITLIST_ADMIN_TOKEN"] = "test-admin-token"
os.environ["WAITLIST_IP_SALT"] = "test-only-salt-123456789012345678901234567890"
with patch.object(threading.Thread, "start", lambda self: None):
    import service


def call(path, method="GET", body=None, auth=None, query="", remote="192.0.2.10"):
    raw = json.dumps(body or {}).encode()
    environ = {
        "PATH_INFO": path, "QUERY_STRING": query, "REQUEST_METHOD": method,
        "CONTENT_LENGTH": str(len(raw)), "wsgi.input": io.BytesIO(raw),
        "REMOTE_ADDR": remote,
    }
    if auth:
        environ["HTTP_AUTHORIZATION"] = auth
    captured = {}
    def start_response(status, headers):
        captured["status"] = status
        captured["headers"] = dict(headers)
    payload = b"".join(service.app(environ, start_response))
    return captured, payload


class ServiceSmokeTests(unittest.TestCase):
    def test_landing_page_served(self):
        meta, body = call("/")
        self.assertEqual(meta["status"], "200 OK")
        self.assertIn(b"Global AI Agent Census", body)
        self.assertTrue(meta["headers"]["Content-Type"].startswith("text/html"))

    def test_readyz_does_not_leak_internal_error_details(self):
        original = dict(service._state)
        try:
            with service._state_lock:
                service._state.update(last_run_finished_at=None, last_run_status="failed", last_run_error="secret-ish internal trace")
            meta, body = call("/readyz")
            self.assertEqual(meta["status"], "503 Service Unavailable")
            self.assertNotIn(b"secret-ish", body)
        finally:
            with service._state_lock:
                service._state.clear()
                service._state.update(original)

    def test_terms_page_served(self):
        meta, body = call("/terms")
        self.assertEqual(meta["status"], "200 OK")
        self.assertIn(b"Terms of service", body)
        self.assertIn(b"Draft for review", body)

    def test_pricing_page_served(self):
        meta, body = call("/pricing")
        self.assertEqual(meta["status"], "200 OK")
        self.assertIn(b"Developer", body)
        self.assertIn(b"/billing/checkout", body)

    def test_waitlist_requires_consent(self):
        meta, body = call("/api/waitlist", "POST", {"email": "person@example.com", "consent": False})
        self.assertEqual(meta["status"], "400 Bad Request")
        self.assertIn(b"consent", body)

    def test_waitlist_submission_and_admin_export(self):
        meta, body = call("/api/waitlist", "POST", {"email": "person@example.com", "role": "Developer", "consent": True})
        self.assertEqual(meta["status"], "201 Created")
        meta, body = call("/api/waitlist", "GET")
        self.assertEqual(meta["status"], "401 Unauthorized")
        meta, body = call("/api/waitlist", "GET", auth="Bearer test-admin-token")
        self.assertEqual(meta["status"], "200 OK")
        data = json.loads(body)
        self.assertEqual(data["count"], 1)
        self.assertEqual(data["leads"][0]["email"], "person@example.com")

    def test_readiness_is_not_ready_before_first_successful_sync(self):
        original = dict(service._state)
        try:
            with service._state_lock:
                service._state.update(last_run_finished_at=None, last_run_status="starting", last_run_error=None)
            meta, body = call("/readyz")
            self.assertEqual(meta["status"], "503 Service Unavailable")
            self.assertEqual(json.loads(body)["status"], "not_ready")
        finally:
            with service._state_lock:
                service._state.clear()
                service._state.update(original)

    def test_activation_rejects_get_requests(self):
        meta, _ = call("/billing/activate", "GET", query="session_id=cs_test_123")
        self.assertEqual(meta["status"], "404 Not Found")

    def test_activation_requires_configured_billing(self):
        os.environ.pop("STRIPE_SECRET_KEY", None)
        meta, body = call("/billing/activate", "POST", {"session_id": "cs_test_123"})
        self.assertEqual(meta["status"], "400 Bad Request")
        self.assertEqual(json.loads(body)["error"], "missing_session_or_billing_not_configured")

    def test_paid_checkout_disabled_without_stripe(self):
        os.environ.pop("STRIPE_SECRET_KEY", None)
        meta, body = call("/billing/checkout", "POST", {"plan": "developer", "email": "person@example.com"})
        self.assertEqual(meta["status"], "503 Service Unavailable")
        self.assertEqual(json.loads(body)["error"], "billing_not_configured")

    def test_expired_subscription_is_rejected(self):
        raw_key = "gac_test-expired-key"
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        conn = service._db()
        try:
            conn.execute("INSERT OR REPLACE INTO billing_subscriptions VALUES(?,?,?,?,?,?,?)", ("sub-expired-test", "cus-test", "expired@example.com", "developer", "active", int(time.time()) - 3600, service._utcnow()))
            conn.execute("INSERT OR REPLACE INTO api_keys(key_hash,stripe_subscription_id,plan,created_at,revoked) VALUES(?,?,?,?,0)", (key_hash, "sub-expired-test", "developer", service._utcnow()))
            conn.commit()
        finally:
            conn.close()
        meta, body = call("/api/v1/counts", auth="Bearer " + raw_key)
        self.assertEqual(meta["status"], "401 Unauthorized")
        self.assertEqual(json.loads(body)["error"], "subscription_period_expired")

    def test_public_agent_search_includes_source_provenance(self):
        conn = service._db()
        try:
            now = service._utcnow()
            conn.execute("INSERT OR REPLACE INTO agents(agent_id,display_name,description,kind,canonical_identity,operator_verification,metadata_valid,endpoint_reachable,first_seen_at,last_seen_at,record_hash,raw_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", ("test-agent", "Test Agent", "A fixture record", "agent", "test:test-agent", "unverified", 1, 0, now, now, "hash-test", "{}"))
            conn.execute("INSERT OR REPLACE INTO source_records(source_name,source_record_id,agent_id,source_url,first_seen_at,last_seen_at) VALUES(?,?,?,?,?,?)", ("Test Directory", "record-1", "test-agent", "https://example.com/directory", now, now))
            conn.commit()
        finally:
            conn.close()
        meta, body = call("/api/agents", query="q=Test%20Agent")
        self.assertEqual(meta["status"], "200 OK")
        result = json.loads(body)["results"][0]
        self.assertEqual(result["sources"][0]["name"], "Test Directory")
        self.assertEqual(result["sources"][0]["url"], "https://example.com/directory")

    def test_json_responses_are_not_cacheable(self):
        meta, _ = call("/api/waitlist", "GET")
        self.assertEqual(meta["headers"]["Cache-Control"], "no-store")


if __name__ == "__main__":
    unittest.main()
