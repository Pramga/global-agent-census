import unittest
from unittest.mock import patch
from census import (canonical_url, normalized_identity, stable_hash, choose_agent_id,
                    a2a_registry_records, github_markdown_directory_records, ingest_source)

class CensusTests(unittest.TestCase):
    def test_url_normalization(self):
        self.assertEqual(canonical_url("HTTPS://Example.COM:443/a#frag"), "https://example.com/a")
        self.assertIsNone(canonical_url("file:///tmp/x"))

    def test_pipeline_reports_source_failures(self):
        import json
        import tempfile
        from pathlib import Path
        from census import run_pipeline
        with tempfile.TemporaryDirectory() as td:
            cfg = Path(td) / "sources.json"
            cfg.write_text(json.dumps({"sources": [{"name": "Broken fixture", "adapter": "not_a_real_adapter", "enabled": True}]}), encoding="utf-8")
            report = run_pipeline(str(cfg), str(Path(td) / "census.sqlite3"), str(Path(td) / "public"))
            self.assertEqual(report["sources_attempted"], 1)
            self.assertEqual(report["sources_succeeded"], 0)
            self.assertEqual(report["sources_failed"], 1)

    def test_stable_hash_key_order(self):
        self.assertEqual(stable_hash({"a": 1, "b": 2}), stable_hash({"b": 2, "a": 1}))

    def test_identity_priority(self):
        r = {"canonical_identity": "Agent:One", "primary_endpoint": "https://example.com"}
        self.assertEqual(normalized_identity(r), "agent:one")
        self.assertEqual(choose_agent_id(r), choose_agent_id(r.copy()))

    @patch("census.fetch_json")
    def test_a2a_adapter_deduplicates_across_search_terms(self, fetch):
        fetch.return_value = (200, {"agents": [{"id": "agent-1", "displayName": "Weather Agent", "url": "https://agent.example"}]}, {})
        records = a2a_registry_records({"query_terms": ["weather", "forecast"]})
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["canonical_identity"], "a2a:agent-1")

    @patch("census.request_bytes")
    def test_markdown_adapter_indexes_project_links_not_live_endpoints(self, request):
        request.return_value = (200, {"Content-Type": "text/markdown"}, b"- [Example MCP](https://github.com/acme/example-mcp) - Useful server\n")
        records = github_markdown_directory_records({"url": "https://raw.example/readme.md"})
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["kind"], "mcp_project")
        self.assertIsNone(records[0]["primary_endpoint"])

    def test_source_configured_adapters_are_known(self):
        self.assertTrue(callable(ingest_source))

if __name__ == "__main__":
    unittest.main()
